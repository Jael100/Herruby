# Her Ruby — Next.js Monorepo

Midlife vitality platform for women 45–65. Built with Next.js 14 (App Router), React 18, and Turborepo.

---

## Monorepo Structure

```
herruby/
├── apps/
│   ├── web/          → Landing page (Next.js 14, port 3001)
│   │   ├── app/
│   │   │   ├── layout.jsx
│   │   │   ├── page.jsx          ← assembles all sections
│   │   │   ├── globals.css
│   │   │   ├── components/
│   │   │   │   ├── Nav.jsx       ← sticky nav, mobile menu
│   │   │   │   └── ScrollReveal.jsx
│   │   │   └── sections/
│   │   │       ├── Hero.jsx
│   │   │       ├── Problem.jsx   ← problem + market stats
│   │   │       ├── WhoItsFor.jsx
│   │   │       ├── GiftOfHealth.jsx ← employers + family/friends
│   │   │       ├── Vision.jsx
│   │   │       ├── Solution.jsx
│   │   │       ├── HowItWorks.jsx
│   │   │       ├── Team.jsx
│   │   │       ├── CTA.jsx       ← waitlist email capture
│   │   │       └── Footer.jsx
│   │   ├── package.json          @herruby/web
│   │   ├── next.config.js
│   │   ├── vercel.json
│   │   └── .env.local.example
│   │
│   ├── flyer/        → Pilot day event page (Next.js 14, port 3002)
│   │   ├── app/
│   │   │   ├── layout.jsx
│   │   │   ├── page.jsx          ← May 2 2026 event flyer
│   │   │   └── globals.css
│   │   ├── package.json          @herruby/flyer
│   │   ├── next.config.js
│   │   ├── vercel.json
│   │   └── .env.local.example
│   │
│   ├── app/          → Mobile React app (CRA, port 3000)
│   │   ├── src/
│   │   │   ├── App.jsx           ← router with auth flow
│   │   │   ├── components/UI.jsx ← Btn, Input, Toggle, TabBar…
│   │   │   ├── context/          ← AuthContext, WalletContext
│   │   │   ├── lib/              ← api.js, supabase.js, constants.js
│   │   │   └── screens/          ← 11 screens
│   │   ├── public/
│   │   └── package.json          @herruby/app
│   │
│   └── api/          → Express REST API (port 4000)
│       ├── src/
│       │   ├── server.js         ← entry point
│       │   ├── lib/supabase.js
│       │   ├── middleware/auth.js
│       │   └── routes/           ← auth, profile, kyc, body,
│       │                            programs, wallet, circles,
│       │                            hub, webhooks
│       ├── supabase/
│       │   └── 001_schema.sql    ← paste into Supabase SQL editor
│       ├── package.json          @herruby/api
│       └── .env.example
│
├── packages/
│   └── ui/           → Shared design system
│       ├── src/
│       │   ├── tokens.js         ← C (colors), F (font sizes), FONTS, CREDIT_PACKS
│       │   └── index.js          ← Serif, Sans, Btn, Chip, SectionHeader…
│       └── package.json          @herruby/ui
│
├── package.json       ← workspace root + turbo scripts
├── turbo.json
└── README.md
```

---

## Quick Start

### Prerequisites
```bash
node --version   # 18+
npm --version    # 9+
```

### Install all workspaces
```bash
npm install
```
This installs dependencies for all apps and packages in one step.

### Run individual apps

| Command | App | URL |
|---|---|---|
| `npm run web:dev` | Landing page | http://localhost:3001 |
| `npm run flyer:dev` | Event flyer | http://localhost:3002 |
| `npm run app:dev` | Mobile app | http://localhost:3000 |
| `npm run api:dev` | REST API | http://localhost:4000 |
| `npm run dev` | All apps simultaneously | — |

### Build for production
```bash
npm run web:build    # builds landing page
npm run flyer:build  # builds event flyer
npm run app:build    # builds mobile app
npm run build        # builds everything
```

---

## Environment Setup

### 1. Supabase (required — 10 min)

1. Create project at https://supabase.com → Canada (Central) region
2. SQL Editor → paste `apps/api/supabase/001_schema.sql` → Run
3. Copy 3 API keys from Settings → API

### 2. Set env variables

**`apps/api/.env`** (copy from `.env.example`):
```
SUPABASE_URL=https://your-ref.supabase.co
SUPABASE_ANON_KEY=eyJhb...
SUPABASE_SERVICE_ROLE_KEY=eyJhb...
PORT=4000
NODE_ENV=development
FRONTEND_URL=http://localhost:3001
```

**`apps/web/.env.local`** (copy from `.env.local.example`):
```
NEXT_PUBLIC_SUPABASE_URL=https://your-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhb...
```

**`apps/app/.env.local`** (copy from `.env.example`):
```
REACT_APP_SUPABASE_URL=https://your-ref.supabase.co
REACT_APP_SUPABASE_ANON_KEY=eyJhb...
REACT_APP_API_URL=http://localhost:4000
```

**`apps/flyer/.env.local`** (copy from `.env.local.example`):
```
NEXT_PUBLIC_EVENTBRITE_URL=https://www.eventbrite.ca/e/her-ruby-pilot-day
```

---

## Deploy to Vercel

Each Next.js app deploys independently. The recommended approach is to create two separate Vercel projects.

### Landing Page (`apps/web`)

```bash
# Option A — CLI (from repo root)
npx vercel --cwd apps/web

# Option B — Vercel dashboard
# Import repo → set Root Directory to apps/web
# Framework: Next.js (auto-detected)
```

**Vercel environment variables to add:**
```
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
NEXT_PUBLIC_APP_URL=https://app.herruby.ca
NEXT_PUBLIC_EVENTBRITE_URL=https://...
```

### Event Flyer (`apps/flyer`)

```bash
npx vercel --cwd apps/flyer
```

**Vercel environment variables:**
```
NEXT_PUBLIC_EVENTBRITE_URL=https://www.eventbrite.ca/e/your-event
```

### Deploy API (`apps/api`) → Railway

```bash
cd apps/api
git init && git add . && git commit -m "Her Ruby API"
# push to GitHub → import on railway.app
```

**Railway environment variables:** all keys from `apps/api/.env.example`

---

## Deploy Mobile App (`apps/app`) → Replit

The React mobile app is designed to run alongside the Express API on Replit (one Repl, one process). See the companion `herruby-replit.zip` for the complete Replit-ready package.

For standalone deploy from this monorepo:

```bash
# Build the React app
npm run app:build

# The build output is in apps/app/build/
# Serve it statically or use the API server to serve it
```

---

## Tech Stack

| Layer | Tech |
|---|---|
| Landing page | Next.js 14 App Router, React 18, inline styles |
| Event flyer | Next.js 14 App Router, React 18 |
| Mobile app | Create React App, React 18 |
| API | Node.js, Express 4, Supabase (Postgres) |
| Auth | Supabase Auth (email + Google + Apple OAuth) |
| Payments | Stripe |
| Database | Supabase (Postgres) — Canada Central |
| Monorepo | Turborepo + npm workspaces |
| Shared UI | @herruby/ui (tokens + primitive components) |
| Deployment | Vercel (web/flyer) + Railway (API) |

---

## Shared Design System (`@herruby/ui`)

All apps import brand tokens and primitive components from `@herruby/ui`:

```js
import { C, FONTS, CREDIT_PACKS, Btn, Serif, Sans, SectionHeader } from '@herruby/ui';

// Colors
C.ruby      // #B8292F
C.rubyDeep  // #7D1A1D
C.gold      // #B8862A
C.slate     // #2A2A35

// Typography
FONTS.serif  // 'Cormorant Garamond', Georgia, serif
FONTS.sans   // 'DM Sans', system-ui, sans-serif

// Credit packs (Starter $100 / Monthly $180 / Quarterly $320)
CREDIT_PACKS  // [{id, credits, price, label, popular}, ...]
```

---

## Contact

**Her Ruby / Lael Ventures**
info@laelventures.com · Ontario, Canada
