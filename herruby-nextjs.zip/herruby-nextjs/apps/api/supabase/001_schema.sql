-- ============================================================
-- HER RUBY — Complete Supabase Database Schema
-- Run in Supabase SQL Editor: supabase.com → project → SQL Editor
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- USERS
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','admin','instructor')),
  kyc_verified BOOLEAN NOT NULL DEFAULT false,
  email_verified BOOLEAN NOT NULL DEFAULT false,
  email_verify_token TEXT,
  password_reset_token TEXT,
  password_reset_expires TIMESTAMPTZ,
  is_active BOOLEAN NOT NULL DEFAULT true,
  last_login_at TIMESTAMPTZ,
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_users_email ON users(email);

-- USER PROFILES
CREATE TABLE user_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  age_range TEXT, context TEXT, menopause_stage TEXT,
  goals TEXT[], symptoms TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

-- NOTIFICATION PREFERENCES
CREATE TABLE notification_preferences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_reminders BOOLEAN NOT NULL DEFAULT true,
  circle_activity BOOLEAN NOT NULL DEFAULT true,
  hub_live BOOLEAN NOT NULL DEFAULT true,
  wallet_updates BOOLEAN NOT NULL DEFAULT true,
  weekly_summary BOOLEAN NOT NULL DEFAULT true,
  marketing_emails BOOLEAN NOT NULL DEFAULT false,
  push_enabled BOOLEAN NOT NULL DEFAULT true,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

-- KYC
CREATE TABLE kyc_inquiries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'persona',
  persona_inquiry_id TEXT,
  status TEXT NOT NULL DEFAULT 'initiated' CHECK (status IN ('initiated','pending','approved','declined','expired')),
  reviewed_at TIMESTAMPTZ,
  raw_payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_kyc_user ON kyc_inquiries(user_id);

-- WALLETS
CREATE TABLE wallets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  funding_source TEXT NOT NULL DEFAULT 'none' CHECK (funding_source IN ('none','self','employer','gift','mixed')),
  employer_name TEXT,
  employer_code_id UUID,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id)
);

CREATE TABLE wallet_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('self_topup','employer_allocation','gift_received','redemption','refund','adjustment')),
  credits INTEGER NOT NULL,
  description TEXT NOT NULL,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_wallet_tx_user ON wallet_transactions(user_id);

-- EMPLOYER CODES
CREATE TABLE employer_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  company_name TEXT NOT NULL,
  credits_per_user INTEGER NOT NULL DEFAULT 10,
  uses_remaining INTEGER,
  is_active BOOLEAN NOT NULL DEFAULT true,
  valid_until TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO employer_codes (code, company_name, credits_per_user) VALUES
  ('ACCENTURE-2025-HR', 'Accenture Canada', 10),
  ('RBC-WELLNESS-25', 'RBC Royal Bank', 12),
  ('DELOITTE-HER-25', 'Deloitte Canada', 10);

-- GIFT CREDITS
CREATE TABLE gift_credits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES users(id),
  recipient_email TEXT NOT NULL,
  redeemed_by UUID REFERENCES users(id),
  package_id TEXT NOT NULL,
  credits INTEGER NOT NULL,
  amount_cad NUMERIC(8,2) NOT NULL,
  personal_message TEXT,
  gift_code TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending_payment' CHECK (status IN ('pending_payment','paid','redeemed','expired')),
  payment_intent_id TEXT,
  redeemed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- PROGRAMS
CREATE TABLE programs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL, category TEXT NOT NULL,
  icon TEXT, color TEXT, intensity TEXT, duration_weeks INTEGER,
  price_cad NUMERIC(8,2) NOT NULL DEFAULT 0,
  description TEXT, outcomes TEXT[],
  next_session_at TIMESTAMPTZ,
  spots_total INTEGER NOT NULL DEFAULT 15,
  spots_remaining INTEGER NOT NULL DEFAULT 15,
  host_name TEXT, host_title TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO programs (name,category,icon,color,intensity,duration_weeks,price_cad,description,outcomes,next_session_at,spots_total,spots_remaining,host_name,host_title) VALUES
('Reclaim Strength & Balance','Signature Programs','⚖️','#B8292F','Gentle-Moderate',6,180.00,'Functional strength, balance drills, posture correction.',ARRAY['Sit-to-stand','Walking confidence'],NOW()+INTERVAL '3 days',15,11,'Sarah Chen','Physiotherapist'),
('Energy & Sleep Reset','Signature Programs','🌙','#5C6BC0','Gentle',4,140.00,'Breathwork, sleep hygiene coaching.',ARRAY['Better sleep','More daytime energy'],NOW()+INTERVAL '5 days',15,9,'Dr. Priya Nair','Wellness Physician'),
('Brain & Body Vitality','Signature Programs','🧠','#27AE8F','Moderate',6,180.00,'Dual-task exercises, coordination drills.',ARRAY['Sharper cognition','Better coordination'],NOW()+INTERVAL '4 days',12,9,'Dr. Amanda Koh','Neurologist'),
('Brampton Lunch Club','Social','☕','#B8292F',NULL,NULL,0.00,'Monthly lunch at a local restaurant.',NULL,NOW()+INTERVAL '10 days',20,17,'Her Ruby Community',NULL),
('Nordic Walking Clinic','Outdoor','🚶‍♀️','#5E8C61','Gentle',NULL,15.00,'Low-impact full-body walk using poles.',NULL,NOW()+INTERVAL '7 days',12,9,'Certified NW Instructor',NULL);

-- BOOKINGS
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  program_id UUID NOT NULL REFERENCES programs(id),
  payment_intent_id TEXT,
  amount_paid_cad NUMERIC(8,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed','cancelled','attended','no_show')),
  attended_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, program_id)
);

-- SESSION REPORTS
CREATE TABLE session_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  program_id UUID NOT NULL REFERENCES programs(id),
  energy_score INTEGER CHECK (energy_score BETWEEN 1 AND 5),
  mood_score INTEGER CHECK (mood_score BETWEEN 1 AND 5),
  challenge_score INTEGER CHECK (challenge_score BETWEEN 1 AND 5),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- BODY CHECK-INS
CREATE TABLE body_checkins (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  energy_level INTEGER CHECK (energy_level BETWEEN 1 AND 5),
  symptom_energy INTEGER CHECK (symptom_energy BETWEEN 1 AND 10),
  symptom_brainfog INTEGER CHECK (symptom_brainfog BETWEEN 1 AND 10),
  symptom_stress INTEGER CHECK (symptom_stress BETWEEN 1 AND 10),
  symptom_sleep INTEGER CHECK (symptom_sleep BETWEEN 1 AND 10),
  symptom_hotflash INTEGER CHECK (symptom_hotflash BETWEEN 1 AND 10),
  symptom_mood INTEGER CHECK (symptom_mood BETWEEN 1 AND 10),
  checked_in_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_checkins_user_date ON body_checkins(user_id, checked_in_at DESC);

-- CIRCLES
CREATE TABLE circles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL, topic TEXT NOT NULL,
  emoji TEXT, color TEXT,
  member_count INTEGER NOT NULL DEFAULT 0,
  max_members INTEGER NOT NULL DEFAULT 20,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
INSERT INTO circles (name,topic,emoji,color) VALUES
('Morning Blossoms','Balance & Movement','🌸','#B8292F'),
('Nourish Together','Nutrition & Recipes','🥗','#5E8C61'),
('Mind Matters','Cognitive Health','🧠','#27AE8F'),
('Travel & Adventure','Travel after 60','✈️','#5C6BC0'),
('Sleep Sisters','Sleep & Recovery','🌙','#9B7EC8'),
('Giving Back','Volunteering & Purpose','🤝','#B8862A');

CREATE TABLE circle_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  circle_id UUID NOT NULL REFERENCES circles(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, circle_id)
);

CREATE TABLE circle_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  circle_id UUID NOT NULL REFERENCES circles(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content TEXT NOT NULL, topic TEXT,
  likes_count INTEGER NOT NULL DEFAULT 0,
  replies_count INTEGER NOT NULL DEFAULT 0,
  is_visible BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_posts_circle ON circle_posts(circle_id, created_at DESC);

-- NOTIFICATIONS QUEUE
CREATE TABLE notifications_queue (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  scheduled_for TIMESTAMPTZ NOT NULL,
  sent_at TIMESTAMPTZ,
  payload JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notif_scheduled ON notifications_queue(scheduled_for) WHERE sent_at IS NULL;

-- ATOMIC add_credits FUNCTION
CREATE OR REPLACE FUNCTION add_credits(
  p_user_id UUID, p_credits INTEGER,
  p_description TEXT, p_type TEXT, p_metadata JSONB DEFAULT NULL
) RETURNS void AS $$
BEGIN
  INSERT INTO wallet_transactions (user_id,type,credits,description,metadata)
  VALUES (p_user_id, p_type, p_credits, p_description, p_metadata);
  UPDATE wallets SET balance = balance + p_credits, updated_at = NOW()
  WHERE user_id = p_user_id;
  IF (SELECT balance FROM wallets WHERE user_id = p_user_id) < 0 THEN
    RAISE EXCEPTION 'Insufficient credits';
  END IF;
END;
$$ LANGUAGE plpgsql;

-- ROW LEVEL SECURITY
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE kyc_inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE body_checkins ENABLE ROW LEVEL SECURITY;
ALTER TABLE session_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE circle_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE circle_posts ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_own ON users USING (id = auth.uid()) WITH CHECK (id = auth.uid());
CREATE POLICY own_profile ON user_profiles USING (user_id = auth.uid());
CREATE POLICY own_notif ON notification_preferences USING (user_id = auth.uid());
CREATE POLICY own_kyc ON kyc_inquiries USING (user_id = auth.uid());
CREATE POLICY own_wallet ON wallets USING (user_id = auth.uid());
CREATE POLICY own_wallet_tx ON wallet_transactions USING (user_id = auth.uid());
CREATE POLICY own_bookings ON bookings USING (user_id = auth.uid());
CREATE POLICY own_checkins ON body_checkins USING (user_id = auth.uid());
CREATE POLICY own_reports ON session_reports USING (user_id = auth.uid());
CREATE POLICY own_circle_members ON circle_members USING (user_id = auth.uid());
CREATE POLICY circle_posts_select ON circle_posts FOR SELECT
  USING (circle_id IN (SELECT circle_id FROM circle_members WHERE user_id = auth.uid()) AND is_visible = true);
CREATE POLICY circle_posts_insert ON circle_posts FOR INSERT WITH CHECK (user_id = auth.uid());
