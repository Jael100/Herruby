// src/routes/kyc.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();
router.use(requireAuth);

// GET /api/kyc/status
router.get('/status', async (req, res) => {
  const { data: profile } = await supabase
    .from('profiles')
    .select('kyc_status, kyc_submitted_at, kyc_verified_at')
    .eq('id', req.user.id)
    .single();
  res.json({
    status: profile?.kyc_status || 'pending',
    submitted_at: profile?.kyc_submitted_at,
    verified_at: profile?.kyc_verified_at,
  });
});

// POST /api/kyc/initiate — returns Persona inquiry URL (or mock)
router.post('/initiate', async (req, res) => {
  const { data: profile } = await supabase
    .from('profiles').select('kyc_status').eq('id', req.user.id).single();

  if (profile?.kyc_status === 'verified') {
    return res.json({ already_verified: true });
  }

  // In production: call Persona API to create an inquiry
  // const inquiry = await persona.inquiries.create({ template_id: process.env.PERSONA_TEMPLATE_ID, ... });
  // For now: return a mock session token
  res.json({
    inquiry_id: `mock_inquiry_${req.user.id}`,
    session_token: `mock_token_${Date.now()}`,
    // In production this would be the Persona hosted flow URL:
    redirect_url: null,
  });
});

// POST /api/kyc/submit — called when user has uploaded docs
router.post('/submit', async (req, res) => {
  // In production: validate files, upload to Supabase Storage, trigger Persona
  // For this stub: mark as submitted and simulate quick approval
  const now = new Date().toISOString();

  await supabase.from('kyc_submissions').upsert({
    user_id: req.user.id,
    status: 'submitted',
    submitted_at: now,
    provider: 'manual',
  }, { onConflict: 'user_id' });

  await supabase.from('profiles').update({
    kyc_status: 'submitted',
    kyc_submitted_at: now,
  }).eq('id', req.user.id);

  // Simulate auto-approval after 3 seconds (demo only — remove in production)
  setTimeout(async () => {
    await supabase.from('profiles').update({
      kyc_status: 'verified',
      kyc_verified_at: new Date().toISOString(),
    }).eq('id', req.user.id);
    await supabase.from('kyc_submissions').update({
      status: 'approved', reviewed_at: new Date().toISOString(),
    }).eq('user_id', req.user.id);
  }, 3000);

  res.json({ success: true, status: 'submitted', message: 'Identity submitted. Approval usually takes under 5 minutes.' });
});

// POST /api/kyc/webhook — called by Persona when verification is complete
router.post('/webhook', express.json(), async (req, res) => {
  const { data } = req.body;
  if (!data) return res.sendStatus(400);

  const userId = data.attributes?.reference_id;
  const status = data.attributes?.status; // 'approved' | 'declined'

  if (userId && status === 'approved') {
    await supabase.from('profiles').update({
      kyc_status: 'verified',
      kyc_verified_at: new Date().toISOString(),
      kyc_provider_ref: data.id,
    }).eq('id', userId);

    await supabase.from('kyc_submissions').update({
      status: 'approved', reviewed_at: new Date().toISOString(), provider_ref_id: data.id,
    }).eq('user_id', userId);
  } else if (userId && status === 'declined') {
    await supabase.from('profiles').update({ kyc_status: 'rejected' }).eq('id', userId);
    await supabase.from('kyc_submissions').update({
      status: 'rejected', rejection_reason: data.attributes?.reason,
    }).eq('user_id', userId);
  }

  res.sendStatus(200);
});

module.exports = router;
