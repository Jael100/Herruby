// src/routes/profile.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();
router.use(requireAuth);

// GET /api/profile
router.get('/', async (req, res) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', req.user.id)
    .single();
  if (error) return res.status(404).json({ error: 'Profile not found' });
  res.json(data);
});

// PATCH /api/profile
router.patch('/', async (req, res) => {
  const allowed = ['name', 'phone', 'avatar_url', 'notification_prefs'];
  const updates = Object.fromEntries(
    Object.entries(req.body).filter(([k]) => allowed.includes(k))
  );
  updates.updated_at = new Date().toISOString();

  const { data, error } = await supabase
    .from('profiles').update(updates).eq('id', req.user.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// POST /api/profile/onboarding
router.post('/onboarding', async (req, res) => {
  const { age_range, work_context, menopause_stage, goals, tracked_symptoms } = req.body;
  const { data, error } = await supabase
    .from('profiles')
    .update({ age_range, work_context, menopause_stage, goals, tracked_symptoms, onboarding_complete: true })
    .eq('id', req.user.id).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

module.exports = router;
