// src/routes/circles.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth, requireKYC } = require('../middleware/auth');
const router = express.Router();

// GET /api/circles — public list
router.get('/', async (req, res) => {
  const { data, error } = await supabase
    .from('circles').select('*').eq('is_active', true).order('name');
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// POST /api/circles/:id/join — requires KYC
router.post('/:id/join', requireAuth, requireKYC, async (req, res) => {
  const { id } = req.params;
  const { data: existing } = await supabase
    .from('circle_memberships').select('id').eq('circle_id', id).eq('user_id', req.user.id).single();
  if (existing) return res.json({ already_member: true });

  const { data, error } = await supabase
    .from('circle_memberships').insert({ circle_id: id, user_id: req.user.id }).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// DELETE /api/circles/:id/leave
router.delete('/:id/leave', requireAuth, async (req, res) => {
  await supabase.from('circle_memberships')
    .delete().eq('circle_id', req.params.id).eq('user_id', req.user.id);
  res.json({ success: true });
});

// GET /api/circles/:id/posts
router.get('/:id/posts', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('circle_posts')
    .select('*, profiles(name)')
    .eq('circle_id', req.params.id)
    .eq('is_deleted', false)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// POST /api/circles/:id/posts
router.post('/:id/posts', requireAuth, async (req, res) => {
  const { content, topic_tag } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content is required' });

  // Verify membership
  const { data: member } = await supabase
    .from('circle_memberships').select('id').eq('circle_id', req.params.id).eq('user_id', req.user.id).single();
  if (!member) return res.status(403).json({ error: 'You must join this circle to post' });

  const { data, error } = await supabase
    .from('circle_posts')
    .insert({ circle_id: req.params.id, user_id: req.user.id, content: content.trim(), topic_tag })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// POST /api/circles/posts/:id/like
router.post('/posts/:id/like', requireAuth, async (req, res) => {
  const { id } = req.params;
  const { data: existing } = await supabase
    .from('post_likes').select('post_id').eq('post_id', id).eq('user_id', req.user.id).single();

  if (existing) {
    await supabase.from('post_likes').delete().eq('post_id', id).eq('user_id', req.user.id);
    await supabase.from('circle_posts').update({ likes_count: supabase.raw('likes_count - 1') }).eq('id', id);
    return res.json({ liked: false });
  }

  await supabase.from('post_likes').insert({ post_id: id, user_id: req.user.id });
  await supabase.from('circle_posts').update({ likes_count: supabase.raw('likes_count + 1') }).eq('id', id);
  res.json({ liked: true });
});

// GET /api/circles/events
router.get('/events', async (req, res) => {
  const { data, error } = await supabase
    .from('circle_events').select('*, circles(name, colour)')
    .order('event_date', { ascending: true });
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// POST /api/circles/events/:id/rsvp
router.post('/events/:id/rsvp', requireAuth, async (req, res) => {
  const { status } = req.body;
  const { data, error } = await supabase
    .from('circle_rsvps')
    .upsert({ circle_event_id: req.params.id, user_id: req.user.id, status: status || 'going' }, { onConflict: 'circle_event_id,user_id' })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

module.exports = router;
