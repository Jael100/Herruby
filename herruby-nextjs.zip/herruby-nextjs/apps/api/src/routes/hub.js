// src/routes/hub.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();

// GET /api/hub/categories
router.get('/categories', async (req, res) => {
  const { data, error } = await supabase
    .from('hub_categories').select('*').order('sort_order');
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// GET /api/hub/content?category=career&type=live
router.get('/content', async (req, res) => {
  const { category, type } = req.query;
  let query = supabase.from('hub_content')
    .select('*, hub_categories(slug, label, colour)')
    .eq('is_published', true);
  if (type) query = query.eq('type', type);
  if (category) {
    const { data: cat } = await supabase
      .from('hub_categories').select('id').eq('slug', category).single();
    if (cat) query = query.eq('category_id', cat.id);
  }
  const { data, error } = await query.order('sort_order');
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// POST /api/hub/content/:id/register
router.post('/content/:id/register', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('hub_registrations')
    .upsert({ content_id: req.params.id, user_id: req.user.id }, { onConflict: 'content_id,user_id' })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// POST /api/hub/content/:id/save
router.post('/content/:id/save', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('saved_content')
    .upsert({ content_id: req.params.id, user_id: req.user.id }, { onConflict: 'content_id,user_id' })
    .select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

// DELETE /api/hub/content/:id/save
router.delete('/content/:id/save', requireAuth, async (req, res) => {
  await supabase.from('saved_content')
    .delete().eq('content_id', req.params.id).eq('user_id', req.user.id);
  res.json({ success: true });
});

module.exports = router;
