// src/routes/wallet.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const stripe = process.env.STRIPE_SECRET_KEY
  ? require('stripe')(process.env.STRIPE_SECRET_KEY)
  : null;
const router = express.Router();
router.use(requireAuth);

const CREDIT_PACKS = {
  p1: { credits: 5,  price_cents: 10000, label: 'Starter' },
  p2: { credits: 10, price_cents: 18000, label: 'Monthly' },
  p3: { credits: 20, price_cents: 32000, label: 'Quarterly' },
};
const CREDIT_VALUE_CAD = 20;

// GET /api/wallet
router.get('/', async (req, res) => {
  const { data: wallet } = await supabase
    .from('wallets').select('balance, funding_source')
    .eq('user_id', req.user.id).single();

  const { data: transactions } = await supabase
    .from('wallet_transactions')
    .select('*')
    .eq('user_id', req.user.id)
    .order('created_at', { ascending: false })
    .limit(50);

  res.json({
    balance: wallet?.balance || 0,
    funding_source: wallet?.funding_source || null,
    credit_value_cad: CREDIT_VALUE_CAD,
    transactions: transactions || [],
  });
});

// POST /api/wallet/topup/initiate — create Stripe PaymentIntent
router.post('/topup/initiate', async (req, res) => {
  const { packageId } = req.body;
  const pack = CREDIT_PACKS[packageId];
  if (!pack) return res.status(400).json({ error: 'Invalid package ID' });

  if (!stripe) {
    // Mock response when Stripe not configured
    return res.json({
      client_secret: 'mock_pi_secret',
      payment_intent_id: `mock_pi_${Date.now()}`,
      amount_cad: pack.price_cents / 100,
      credits: pack.credits,
    });
  }

  const paymentIntent = await stripe.paymentIntents.create({
    amount: pack.price_cents,
    currency: 'cad',
    metadata: { user_id: req.user.id, package_id: packageId, credits: pack.credits },
  });

  res.json({
    client_secret: paymentIntent.client_secret,
    payment_intent_id: paymentIntent.id,
    amount_cad: pack.price_cents / 100,
    credits: pack.credits,
  });
});

// POST /api/wallet/topup/confirm — called after successful payment
router.post('/topup/confirm', async (req, res) => {
  const { payment_intent_id, package_id } = req.body;
  const pack = CREDIT_PACKS[package_id];
  if (!pack) return res.status(400).json({ error: 'Invalid package ID' });

  // Get or create wallet
  let { data: wallet } = await supabase
    .from('wallets').select('id, balance').eq('user_id', req.user.id).single();

  if (!wallet) {
    const { data: newWallet } = await supabase
      .from('wallets').insert({ user_id: req.user.id, balance: 0, funding_source: 'self' })
      .select().single();
    wallet = newWallet;
  }

  const newBalance = (wallet.balance || 0) + pack.credits;
  await supabase.from('wallets')
    .update({ balance: newBalance, funding_source: 'self' })
    .eq('user_id', req.user.id);

  await supabase.from('wallet_transactions').insert({
    wallet_id: wallet.id, user_id: req.user.id,
    type: 'credit', amount: pack.credits,
    description: `Top-up: ${pack.label} (${pack.credits} credits)`,
    source: 'self_topup',
    stripe_payment_intent_id: payment_intent_id,
  });

  res.json({ success: true, new_balance: newBalance, credits_added: pack.credits });
});

// POST /api/wallet/gift/send
router.post('/gift/send', async (req, res) => {
  const { recipient_email, package_id, message, payment_intent_id } = req.body;
  const pack = CREDIT_PACKS[package_id];
  if (!pack || !recipient_email) {
    return res.status(400).json({ error: 'recipient_email and package_id are required' });
  }

  const code = `GIFT-${Math.random().toString(36).substr(2,6).toUpperCase()}-${Math.random().toString(36).substr(2,4).toUpperCase()}`;

  const { data: gift, error } = await supabase
    .from('gift_codes').insert({
      code, sender_user_id: req.user.id,
      recipient_email, credits: pack.credits,
      price_paid_cents: pack.price_cents,
      stripe_payment_intent_id: payment_intent_id,
      message,
    }).select().single();

  if (error) return res.status(400).json({ error: error.message });

  // In production: send email via nodemailer/SendGrid here

  res.status(201).json({ success: true, code, credits: pack.credits, recipient: recipient_email });
});

// POST /api/wallet/gift/redeem
router.post('/gift/redeem', async (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'Gift code is required' });

  const { data: gift, error } = await supabase
    .from('gift_codes').select('*').eq('code', code.toUpperCase()).single();

  if (error || !gift) return res.status(404).json({ error: 'Invalid or expired gift code' });
  if (gift.redeemed) return res.status(409).json({ error: 'This gift code has already been used' });
  if (gift.expires_at && new Date(gift.expires_at) < new Date()) {
    return res.status(400).json({ error: 'This gift code has expired' });
  }

  // Mark redeemed
  await supabase.from('gift_codes').update({
    redeemed: true, redeemed_by: req.user.id, redeemed_at: new Date().toISOString(),
  }).eq('id', gift.id);

  // Add to wallet
  let { data: wallet } = await supabase
    .from('wallets').select('id, balance').eq('user_id', req.user.id).single();
  if (!wallet) {
    const { data: nw } = await supabase
      .from('wallets').insert({ user_id: req.user.id, balance: 0, funding_source: 'gift' })
      .select().single();
    wallet = nw;
  }

  const newBalance = (wallet.balance || 0) + gift.credits;
  await supabase.from('wallets').update({ balance: newBalance, funding_source: 'gift' }).eq('user_id', req.user.id);
  await supabase.from('wallet_transactions').insert({
    wallet_id: wallet.id, user_id: req.user.id,
    type: 'credit', amount: gift.credits,
    description: 'Gift credits received',
    source: 'gift_received', gift_code: code,
  });

  res.json({ success: true, credits_added: gift.credits, new_balance: newBalance });
});

// POST /api/wallet/employer/activate
router.post('/employer/activate', async (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'Employer code is required' });

  const { data: emp, error } = await supabase
    .from('employer_codes').select('*').eq('code', code.toUpperCase()).eq('active', true).single();

  if (error || !emp) return res.status(404).json({ error: 'Invalid employer code. Contact your HR team.' });
  if (emp.expires_at && new Date(emp.expires_at) < new Date()) {
    return res.status(400).json({ error: 'This employer code has expired. Contact HR.' });
  }
  if (emp.max_users && emp.used_count >= emp.max_users) {
    return res.status(400).json({ error: 'This employer code has reached its user limit. Contact HR.' });
  }

  // Increment usage count
  await supabase.from('employer_codes').update({ used_count: emp.used_count + 1 }).eq('id', emp.id);

  // Add credits to wallet
  let { data: wallet } = await supabase
    .from('wallets').select('id, balance').eq('user_id', req.user.id).single();
  if (!wallet) {
    const { data: nw } = await supabase
      .from('wallets').insert({ user_id: req.user.id, balance: 0 }).select().single();
    wallet = nw;
  }

  const newBalance = (wallet.balance || 0) + emp.credits_per_user;
  await supabase.from('wallets').update({
    balance: newBalance, funding_source: 'employer', employer_code: code.toUpperCase(),
  }).eq('user_id', req.user.id);

  await supabase.from('wallet_transactions').insert({
    wallet_id: wallet.id, user_id: req.user.id,
    type: 'credit', amount: emp.credits_per_user,
    description: `Employer allocation — ${emp.company_name}`,
    source: 'employer_allocation',
  });

  res.json({ success: true, company: emp.company_name, credits_added: emp.credits_per_user, new_balance: newBalance });
});

module.exports = router;
