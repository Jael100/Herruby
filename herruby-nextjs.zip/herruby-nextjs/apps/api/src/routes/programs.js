// src/routes/programs.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth, requireKYC } = require('../middleware/auth');
const router = express.Router();

// GET /api/programs — public
router.get('/', async (req, res) => {
  const { category, schedule } = req.query;
  let query = supabase.from('events').select('*').eq('is_active', true);
  if (category && category !== 'All') query = query.eq('category', category);
  const { data, error } = await query.order('next_date', { ascending: true });
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// GET /api/programs/bookings — user's own bookings
router.get('/bookings', requireAuth, async (req, res) => {
  const { data, error } = await supabase
    .from('bookings')
    .select('*, events(*)')
    .eq('user_id', req.user.id)
    .order('created_at', { ascending: false });
  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// POST /api/programs/book — requires auth; KYC required for paid events
router.post('/book', requireAuth, async (req, res) => {
  const { event_id, payment_method, credits_used, stripe_payment_intent_id } = req.body;
  if (!event_id) return res.status(400).json({ error: 'event_id is required' });

  // Fetch event to check price
  const { data: event, error: evErr } = await supabase
    .from('events').select('*').eq('id', event_id).single();
  if (evErr || !event) return res.status(404).json({ error: 'Event not found' });

  // KYC required for paid events
  if (Number(event.price_cad) > 0) {
    const { data: profile } = await supabase
      .from('profiles').select('kyc_status').eq('id', req.user.id).single();
    if (profile?.kyc_status !== 'verified') {
      return res.status(403).json({
        error: 'identity_verification_required',
        message: 'Please verify your identity before booking paid sessions.',
      });
    }
  }

  // Check not already booked
  const { data: existing } = await supabase
    .from('bookings').select('id').eq('user_id', req.user.id).eq('event_id', event_id).single();
  if (existing) return res.status(409).json({ error: 'You are already booked for this event' });

  // If paying by wallet, deduct credits
  if (payment_method === 'wallet' && credits_used > 0) {
    const { data: wallet } = await supabase
      .from('wallets').select('balance, id').eq('user_id', req.user.id).single();
    if (!wallet || wallet.balance < credits_used) {
      return res.status(400).json({ error: 'Insufficient wallet credits' });
    }
    await supabase.from('wallets')
      .update({ balance: wallet.balance - credits_used })
      .eq('user_id', req.user.id);
    await supabase.from('wallet_transactions').insert({
      wallet_id: wallet.id, user_id: req.user.id,
      type: 'debit', amount: credits_used,
      description: `Booking: ${event.name}`,
      source: 'redemption',
    });
  }

  const { data: booking, error: bookErr } = await supabase
    .from('bookings')
    .insert({
      user_id: req.user.id, event_id,
      payment_method: payment_method || 'free',
      credits_used: credits_used || 0,
      amount_paid_cents: stripe_payment_intent_id ? Math.round(Number(event.price_cad) * 113) : 0,
      stripe_payment_intent_id,
      status: 'confirmed',
    })
    .select()
    .single();

  if (bookErr) return res.status(400).json({ error: bookErr.message });
  res.status(201).json({ booking, event });
});

// PATCH /api/programs/bookings/:id/report
router.patch('/bookings/:id/report', requireAuth, async (req, res) => {
  const { id } = req.params;
  const { energy, mood, challenge, notes } = req.body;

  const { data, error } = await supabase
    .from('bookings')
    .update({ session_report: { energy, mood, challenge, notes }, status: 'attended' })
    .eq('id', id).eq('user_id', req.user.id)
    .select().single();

  if (error) return res.status(400).json({ error: error.message });
  res.json(data);
});

module.exports = router;
