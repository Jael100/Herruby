// src/routes/auth.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();

// POST /api/auth/signup
router.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'name, email and password are required' });
  if (password.length < 8)
    return res.status(400).json({ error: 'Password must be at least 8 characters' });

  const { data, error } = await supabase.auth.admin.createUser({
    email, password,
    email_confirm: true,           // skip email verification in dev
    user_metadata: { name },
  });
  if (error) {
    if (error.message.includes('already registered'))
      return res.status(409).json({ error: 'An account with this email already exists.' });
    return res.status(400).json({ error: error.message });
  }

  // Update auto-created profile row with name
  await supabase.from('profiles').update({ name }).eq('id', data.user.id);

  // Sign them in and return session
  const { data: session, error: signInErr } = await supabase.auth.signInWithPassword({ email, password });
  if (signInErr) return res.status(500).json({ error: signInErr.message });

  res.status(201).json({
    user: { id: data.user.id, email, name, kyc_status: 'pending', onboarding_complete: false },
    session: session.session,
  });
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: 'Email and password are required' });

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return res.status(401).json({ error: 'Invalid email or password' });

  const { data: profile } = await supabase
    .from('profiles')
    .select('name, kyc_status, onboarding_complete, goals, tracked_symptoms, age_range, work_context, menopause_stage, notification_prefs')
    .eq('id', data.user.id)
    .single();

  res.json({ user: { id: data.user.id, email: data.user.email, ...profile }, session: data.session });
});

// POST /api/auth/logout
router.post('/logout', requireAuth, async (req, res) => {
  await supabase.auth.admin.signOut(req.token || '');
  res.json({ success: true });
});

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'Email is required' });
  // Supabase sends the reset email automatically
  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${process.env.FRONTEND_URL}/reset-password`,
  });
  // Always 200 — never confirm whether email exists
  res.json({ success: true });
});

// POST /api/auth/sync  — called after OAuth (Google/Apple) to ensure profile row exists
router.post('/sync', requireAuth, async (req, res) => {
  const { name, email } = req.body;
  const { data: existing } = await supabase
    .from('profiles').select('id').eq('id', req.user.id).single();

  if (!existing) {
    await supabase.from('profiles').insert({
      id: req.user.id,
      name: name || req.user.user_metadata?.full_name || '',
      email: email || req.user.email || '',
    });
    // Also create a wallet record
    await supabase.from('wallets').insert({ user_id: req.user.id, balance: 0 });
  }
  res.json({ synced: true });
});

module.exports = router;
