// src/routes/webhooks.js
// NOTE: This router receives raw body (not parsed JSON).
// Mounted BEFORE express.json() in server.js.
const express = require('express');
const { supabase } = require('../lib/supabase');
const router = express.Router();

const stripe = process.env.STRIPE_SECRET_KEY
  ? require('stripe')(process.env.STRIPE_SECRET_KEY)
  : null;

// POST /api/webhooks/stripe
router.post('/stripe', async (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) {
    console.log('Stripe not configured — skipping webhook');
    return res.sendStatus(200);
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      req.headers['stripe-signature'],
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Stripe webhook signature failed:', err.message);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const pi = event.data.object;
      const { user_id, package_id, credits } = pi.metadata;

      if (user_id && credits) {
        const creditsNum = parseInt(credits);
        // Get or create wallet
        let { data: wallet } = await supabase
          .from('wallets').select('id, balance').eq('user_id', user_id).single();
        if (!wallet) {
          const { data: nw } = await supabase
            .from('wallets').insert({ user_id, balance: 0, funding_source: 'self' }).select().single();
          wallet = nw;
        }
        const newBalance = (wallet.balance || 0) + creditsNum;
        await supabase.from('wallets').update({ balance: newBalance, funding_source: 'self' }).eq('user_id', user_id);
        await supabase.from('wallet_transactions').insert({
          wallet_id: wallet.id, user_id,
          type: 'credit', amount: creditsNum,
          description: `Wallet top-up — ${creditsNum} credits`,
          source: 'self_topup',
          stripe_payment_intent_id: pi.id,
        });
      }
      break;
    }
    case 'payment_intent.payment_failed': {
      const pi = event.data.object;
      console.error(`Payment failed for user ${pi.metadata.user_id}: ${pi.last_payment_error?.message}`);
      break;
    }
    default:
      console.log(`Unhandled Stripe event: ${event.type}`);
  }

  res.sendStatus(200);
});

module.exports = router;
