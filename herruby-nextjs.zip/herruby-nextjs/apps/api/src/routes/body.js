// src/routes/body.js
const express = require('express');
const { supabase } = require('../lib/supabase');
const { requireAuth } = require('../middleware/auth');
const router = express.Router();
router.use(requireAuth);

// GET /api/body/logs?days=21
router.get('/logs', async (req, res) => {
  const days = parseInt(req.query.days) || 21;
  const since = new Date();
  since.setDate(since.getDate() - days);

  const { data, error } = await supabase
    .from('symptom_logs')
    .select('*')
    .eq('user_id', req.user.id)
    .gte('logged_at', since.toISOString().split('T')[0])
    .order('logged_at', { ascending: false });

  if (error) return res.status(400).json({ error: error.message });
  res.json(data || []);
});

// POST /api/body/logs
router.post('/logs', async (req, res) => {
  const { energy, brainfog, stress, sleep, hotflash, mood, work_energy_level, notes } = req.body;
  const today = new Date().toISOString().split('T')[0];

  const { data, error } = await supabase
    .from('symptom_logs')
    .upsert({
      user_id: req.user.id,
      logged_at: today,
      energy, brainfog, stress, sleep, hotflash, mood, work_energy_level, notes,
    }, { onConflict: 'user_id,logged_at' })
    .select()
    .single();

  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data);
});

// GET /api/body/trends — returns 3 weeks of data per metric
router.get('/trends', async (req, res) => {
  const since = new Date();
  since.setDate(since.getDate() - 21);

  const { data, error } = await supabase
    .from('symptom_logs')
    .select('logged_at, energy, brainfog, stress, sleep, hotflash, mood')
    .eq('user_id', req.user.id)
    .gte('logged_at', since.toISOString().split('T')[0])
    .order('logged_at', { ascending: true });

  if (error) return res.status(400).json({ error: error.message });

  // Split into 3 weeks
  const weeks = [[], [], []];
  const logs = data || [];
  logs.forEach((log, i) => {
    const weekIdx = Math.min(Math.floor(i / 7), 2);
    weeks[weekIdx].push(log);
  });

  res.json({ logs, weeks, total_days: logs.length });
});

module.exports = router;
