// server.js
// Single entry point — serves the React frontend build AND all API routes.
// On Replit: one process, one port. React build is in client/build/.
require('dotenv').config();
const express   = require('express');
const helmet    = require('helmet');
const cors      = require('cors');
const path      = require('path');
const rateLimit = require('express-rate-limit');

// ── Route modules ─────────────────────────────────────────────────────────────
const authRoutes    = require('./src/routes/auth');
const profileRoutes = require('./src/routes/profile');
const kycRoutes     = require('./src/routes/kyc');
const bodyRoutes    = require('./src/routes/body');
const programRoutes = require('./src/routes/programs');
const walletRoutes  = require('./src/routes/wallet');
const circleRoutes  = require('./src/routes/circles');
const hubRoutes     = require('./src/routes/hub');
const webhookRoutes = require('./src/routes/webhooks');

const app = express();
// Replit always uses PORT env var. MUST listen on 0.0.0.0 not localhost.
const PORT = process.env.PORT || 3000;

// ── Security ──────────────────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false, // Disabled so React loads Google Fonts etc.
  crossOriginEmbedderPolicy: false,
}));
app.use(cors({
  origin: true,        // Replit URLs vary; allow all origins in dev
  credentials: true,
  methods: ['GET','POST','PATCH','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));

// ── Stripe/KYC webhooks need raw body BEFORE express.json() ──────────────────
app.use('/api/webhooks/stripe', express.raw({ type: 'application/json' }));
app.use('/api/kyc/webhook',     express.raw({ type: 'application/json' }));

// ── Body parsing ──────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Rate limiting ─────────────────────────────────────────────────────────────
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 30 }));
app.use('/api',      rateLimit({ windowMs: 15 * 60 * 1000, max: 300 }));

// ── Health check (Replit uses this to detect the app is running) ──────────────
app.get('/health', (req, res) => {
  res.json({ status: 'ok', env: process.env.NODE_ENV, ts: new Date().toISOString() });
});

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/profile',  profileRoutes);
app.use('/api/kyc',      kycRoutes);
app.use('/api/body',     bodyRoutes);
app.use('/api/programs', programRoutes);
app.use('/api/wallet',   walletRoutes);
app.use('/api/circles',  circleRoutes);
app.use('/api/hub',      hubRoutes);
app.use('/api/webhooks', webhookRoutes);

// ── Serve React build (production) ───────────────────────────────────────────
const BUILD_DIR = path.join(__dirname, 'client', 'build');
app.use(express.static(BUILD_DIR));
// React Router — any non-API route returns index.html
app.get('*', (req, res) => {
  const index = path.join(BUILD_DIR, 'index.html');
  res.sendFile(index, (err) => {
    if (err) {
      // Build doesn't exist yet — show helpful message
      res.status(200).send(`
        <html><body style="font-family:sans-serif;text-align:center;padding:60px;background:#7D1A1D;color:white">
          <h1 style="font-size:48px">♦</h1>
          <h2>Her Ruby API is running</h2>
          <p>The React frontend hasn't been built yet.</p>
          <p>Run <code style="background:rgba(255,255,255,0.2);padding:4px 8px;border-radius:4px">npm run build</code> in the Shell tab, then restart.</p>
          <p style="opacity:0.6;margin-top:24px">API health: <a href="/health" style="color:#F0D688">/health</a></p>
        </body></html>
      `);
    }
  });
});

// ── Global error handler ─────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  console.error(`[${new Date().toISOString()}] ERROR:`, err.message);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

// ── Listen on 0.0.0.0 — required for Replit to expose the port ───────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n♦ Her Ruby running on port ${PORT}`);
  console.log(`  Health:   http://localhost:${PORT}/health`);
  console.log(`  API base: http://localhost:${PORT}/api`);
  console.log(`  Frontend: http://localhost:${PORT}/\n`);
});

module.exports = app;
