// src/middleware/auth.js
const { supabase, getUserFromToken } = require('../lib/supabase');

// Attach req.user from Supabase JWT. Returns 401 if missing/invalid.
async function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid Authorization header' });
  }
  const token = header.split(' ')[1];
  const user = await getUserFromToken(token);
  if (!user) return res.status(401).json({ error: 'Invalid or expired token' });
  req.user = user;
  next();
}

// Require KYC verified status before proceeding
async function requireKYC(req, res, next) {
  const { data: profile } = await supabase
    .from('profiles')
    .select('kyc_status')
    .eq('id', req.user.id)
    .single();

  if (profile?.kyc_status !== 'verified') {
    return res.status(403).json({
      error: 'identity_verification_required',
      message: 'Complete identity verification to access this feature.',
    });
  }
  next();
}

module.exports = { requireAuth, requireKYC };
