/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@herruby/ui'],
  experimental: { optimizePackageImports: ['@herruby/ui'] },
};

module.exports = nextConfig;
