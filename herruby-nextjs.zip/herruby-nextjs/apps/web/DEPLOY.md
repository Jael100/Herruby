# Her Ruby — Deploy to GitHub & Vercel
## Complete step-by-step guide

---

## What you're deploying

| URL | Folder | What it is |
|---|---|---|
| `herruby.ca` (or your domain) | `apps/web` | Landing page + `/pilot` subpage |
| `herruby.ca/pilot` | `apps/web/app/pilot/` | Pilot event subpage (auto-included) |

Both pages live in the **same Next.js app** (`apps/web`). One Vercel project, one deploy — both URLs work automatically.

---

## Before you start — install these

You need two things on your computer:

**1. Git** — check if you have it:
```bash
git --version
```
If you see `git version 2.x.x` you're good. If not → download from https://git-scm.com

**2. Node.js 18+** — check:
```bash
node --version
```
If you see `v18.x.x` or higher you're good. If not → download from https://nodejs.org (choose "LTS")

---

## PART 1 — GitHub (store your code)

### Step 1 · Create a GitHub account
Go to **github.com** → click **Sign up** → use any email.

```
┌─────────────────────────────────────────────┐
│  github.com                            [Sign up] │
│                                              │
│  Where the world builds software            │
│                                              │
│  [Sign up for GitHub]  [Sign in]            │
└─────────────────────────────────────────────┘
```

---

### Step 2 · Create a new repository
Once signed in, click the **+** icon (top right) → **New repository**

```
┌─────────────────────────────────────────────┐
│  github.com › New repository                 │
│                                              │
│  Repository name:  [herruby-web        ]    │
│                                              │
│  Description: Her Ruby landing page          │
│                                              │
│  ○ Public   ● Private  ← choose Private     │
│                                              │
│  □ Add a README file  ← LEAVE UNCHECKED     │
│  □ Add .gitignore     ← LEAVE UNCHECKED     │
│                                              │
│             [Create repository]              │
└─────────────────────────────────────────────┘
```

**Important:** Leave "Add README" and "Add .gitignore" **unchecked** — your zip already has these files.

After clicking Create, you'll see a page with a URL like:
`https://github.com/yourusername/herruby-web`

Keep this page open — you'll need the URL in Step 5.

---

### Step 3 · Unzip the file on your computer

Unzip `herruby-web.zip` — you'll get a folder called `herruby-web/` containing:

```
herruby-web/
├── app/
│   ├── components/
│   │   ├── Nav.jsx
│   │   └── ScrollReveal.jsx
│   ├── sections/           ← all landing page sections
│   │   ├── Hero.jsx
│   │   ├── Problem.jsx
│   │   ├── WhoItsFor.jsx
│   │   ├── GiftOfHealth.jsx   ← employer popup + gift payment
│   │   ├── Vision.jsx
│   │   ├── Solution.jsx       ← 4 pillars
│   │   ├── AppPreview.jsx     ← phone mockup + download CTA
│   │   ├── HowItWorks.jsx
│   │   ├── Team.jsx
│   │   ├── CTA.jsx
│   │   └── Footer.jsx         ← contact form + app links
│   ├── pilot/              ← /pilot subpage (auto-routed)
│   │   ├── page.jsx
│   │   └── PilotSignup.jsx
│   ├── globals.css
│   ├── layout.jsx
│   └── page.jsx
├── package.json
├── next.config.js
├── vercel.json
├── .env.local.example      ← copy this to .env.local
├── .gitignore
└── DEPLOY.md               ← this file
```

---

### Step 4 · Open Terminal and navigate to the folder

**On Mac:**
Press `Cmd + Space` → type `Terminal` → press Enter

**On Windows:**
Press `Win + R` → type `cmd` → press Enter

Then type (replace the path with where you unzipped):
```bash
cd ~/Downloads/herruby-web
```

Or if on your Desktop:
```bash
cd ~/Desktop/herruby-web
```

Confirm you're in the right place:
```bash
ls
```
You should see: `app/  package.json  next.config.js  vercel.json  ...`

---

### Step 5 · Initialise Git and push to GitHub

Copy and run these commands **one line at a time**:

```bash
# 1. Initialise git in this folder
git init

# 2. Add all files
git add .

# 3. Create your first commit
git commit -m "Initial commit — Her Ruby landing page + pilot subpage"

# 4. Name the main branch
git branch -M main

# 5. Connect to your GitHub repo
#    Replace YOUR-USERNAME with your GitHub username
git remote add origin https://github.com/YOUR-USERNAME/herruby-web.git

# 6. Push your code to GitHub
git push -u origin main
```

After Step 6 you'll see something like:
```
Enumerating objects: 28, done.
Writing objects: 100% (28/28), done.
Branch 'main' set up to track remote branch 'main' from 'origin'.
```

**Refresh your GitHub page** — you should now see all your files there.

```
┌─────────────────────────────────────────────────┐
│  github.com/yourusername/herruby-web             │
│                                                   │
│  📁 app/                                          │
│  📄 .gitignore                                    │
│  📄 DEPLOY.md                                     │
│  📄 next.config.js                                │
│  📄 package.json                                  │
│  📄 vercel.json                                   │
│                                                   │
│  ✓  1 commit  ·  main                            │
└─────────────────────────────────────────────────┘
```

---

## PART 2 — Vercel (publish your site)

### Step 6 · Create a Vercel account
Go to **vercel.com** → click **Sign Up** → choose **Continue with GitHub**

```
┌─────────────────────────────────────────────┐
│  vercel.com › Sign Up                        │
│                                              │
│  Create your Vercel account                 │
│                                              │
│  [▶ Continue with GitHub]  ← click this     │
│  [Continue with GitLab  ]                    │
│  [Continue with Bitbucket]                   │
└─────────────────────────────────────────────┘
```

Authorise Vercel to access GitHub when prompted. This connects them so Vercel can read your code.

---

### Step 7 · Import your repository
On the Vercel dashboard → click **Add New…** → **Project**

```
┌─────────────────────────────────────────────┐
│  vercel.com › New Project                    │
│                                              │
│  Import Git Repository                       │
│                                              │
│  herruby-web          [Import]  ← click     │
│  github.com/you/herruby-web                  │
│                                              │
│  [Search repos...]                           │
└─────────────────────────────────────────────┘
```

Click **Import** next to `herruby-web`.

---

### Step 8 · Configure the project

This is the most important step. Fill in these settings exactly:

```
┌─────────────────────────────────────────────┐
│  vercel.com › Configure Project              │
│                                              │
│  Project Name:                               │
│  [herruby-web                          ]     │
│                                              │
│  Framework Preset:                           │
│  [Next.js                           ▼]  ← auto-detected │
│                                              │
│  Root Directory:                             │
│  [./                               ] ← leave as is │
│                                              │
│  Build Command:     (leave blank — auto)     │
│  Output Directory:  (leave blank — auto)     │
│  Install Command:   (leave blank — auto)     │
│                                              │
└─────────────────────────────────────────────┘
```

**Do not change the Root Directory** — the `vercel.json` file handles everything automatically.

---

### Step 9 · Add Environment Variables

Still on the configure page, scroll down to **Environment Variables** and add these:

```
┌─────────────────────────────────────────────┐
│  Environment Variables                        │
│                                              │
│  NAME                    VALUE               │
│  ─────────────────────────────────────────── │
│  NEXT_PUBLIC_EVENTBRITE_URL                  │
│  → https://www.eventbrite.ca/e/your-event    │
│                                              │
│  NEXT_PUBLIC_APP_URL                         │
│  → https://herruby.ca                        │
│                                              │
│  (Add more later via Project Settings)       │
└─────────────────────────────────────────────┘
```

To add each one:
1. Click **Add** (or the + button)
2. Type the name in the left field
3. Type the value in the right field
4. Make sure all three environments are ticked: ✓ Production  ✓ Preview  ✓ Development

**Minimum required for launch:**
- `NEXT_PUBLIC_EVENTBRITE_URL` — your Eventbrite link (paste it from Eventbrite)
- `NEXT_PUBLIC_APP_URL` — your domain (use the `.vercel.app` URL for now, update later)

---

### Step 10 · Deploy

Click **Deploy** — Vercel will build and publish your site.

```
┌─────────────────────────────────────────────┐
│  vercel.com › Deploying herruby-web          │
│                                              │
│  ● Cloning repository...          ✓ done    │
│  ● Installing dependencies...     ✓ done    │
│  ● Building (Next.js)...          ✓ done    │
│  ● Assigning domain...            ✓ done    │
│                                              │
│  🎉  Your project is live!                   │
│                                              │
│  https://herruby-web.vercel.app    [Visit]   │
└─────────────────────────────────────────────┘
```

Build takes about 60–90 seconds. When done you'll get a URL like:
`https://herruby-web.vercel.app`

Your two pages are live at:
- `https://herruby-web.vercel.app` — landing page
- `https://herruby-web.vercel.app/pilot` — pilot event page

---

## PART 3 — Custom Domain (optional)

### Step 11 · Add herruby.ca to Vercel

In your Vercel project → **Settings** → **Domains** → type `herruby.ca` → **Add**

```
┌─────────────────────────────────────────────┐
│  Project Settings › Domains                  │
│                                              │
│  Add domain:  [herruby.ca            ] [Add] │
│                                              │
│  Vercel will show you DNS records to copy:   │
│                                              │
│  Type    Name    Value                       │
│  A       @       76.76.21.21                 │
│  CNAME   www     cname.vercel-dns.com        │
│                                              │
└─────────────────────────────────────────────┘
```

### Step 12 · Update DNS at your domain registrar

Log into wherever you bought `herruby.ca` (e.g. GoDaddy, Namecheap, Google Domains) → DNS settings → add these records:

```
┌─────────────────────────────────────────────┐
│  DNS Records (your registrar's dashboard)    │
│                                              │
│  Type   Host   Value              TTL        │
│  ─────────────────────────────────────────── │
│  A      @      76.76.21.21        Auto       │
│  CNAME  www    cname.vercel-dns.com  Auto    │
└─────────────────────────────────────────────┘
```

DNS changes take 5 minutes to 24 hours to propagate. Vercel will show a green ✓ when it's verified.

---

## PART 4 — Future updates

### Every time you make changes to your code:

```bash
# Navigate to your folder
cd ~/Downloads/herruby-web

# See what changed
git status

# Stage all changes
git add .

# Commit with a message describing what you changed
git commit -m "Update pilot event date"

# Push to GitHub — Vercel auto-deploys in ~60 seconds
git push
```

**That's it.** Every `git push` triggers a new Vercel deployment automatically.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `git: command not found` | Install Git from git-scm.com |
| `node: command not found` | Install Node.js 18+ from nodejs.org |
| `npm error: peer deps` | Run `npm install --legacy-peer-deps` |
| Build fails on Vercel | Check the build log for errors, ensure env vars are set |
| Fonts not loading | They load from Google Fonts — requires internet connection |
| `/pilot` shows 404 | Make sure `app/pilot/page.jsx` exists in your repo |
| Domain not resolving | Wait up to 24h for DNS, check Vercel Domains dashboard |
| Employer form not sending | Wire `POST /api/employer-enquiry` endpoint (see API docs) |
| Gift payment is mock | Wire Stripe in `GiftOfHealth.jsx` `pay()` function |

---

## Contact
info@laelventures.com · herruby.ca
