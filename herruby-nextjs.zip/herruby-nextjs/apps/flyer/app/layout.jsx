import './globals.css';

export const metadata = {
  title: 'Her Ruby — Pilot Day · Saturday May 2, 2026',
  description: 'Join us for an exclusive first look at Her Ruby. A morning designed for women 45–65 who are ready to invest in themselves. Free event. 10am – 1pm.',
  openGraph: {
    title: 'Her Ruby Pilot Day — Saturday May 2, 2026 · 10am–1pm',
    description: 'Free event. Expert talks, live platform preview, and community for women 45–65.',
    type: 'website',
  },
  themeColor: '#7D1A1D',
};

export default function FlyerLayout({ children }) {
  return (
    <html lang="en">
      <head><meta name="viewport" content="width=device-width, initial-scale=1" /></head>
      <body>{children}</body>
    </html>
  );
}
