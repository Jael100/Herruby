import { C, FONTS } from '@herruby/ui';

const EXPECT = [
  { n: '1', title: 'Platform preview', desc: 'Be the first to see the Her Ruby app and experience it hands-on.' },
  { n: '2', title: 'Expert session', desc: 'A live talk on midlife hormonal health, energy, and performance.' },
  { n: '3', title: 'Ruby Circle', desc: 'Meet other women at this stage and start building your community.' },
  { n: '4', title: 'Q&A + refreshments', desc: 'Ask anything, connect, and leave with tools you can use today.' },
];

const BADGES = [
  'A woman 45–65', 'Navigating menopause', 'Feeling burnt out',
  'An empty nester', 'Curious about midlife', 'Ready to invest in you',
];

export default function FlyerPage() {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '40px 20px 60px',
      background: '#1a0a0a',
    }}>
      <div style={{ width: '100%', maxWidth: 900 }}>

        {/* ── MAIN FLYER CARD ── */}
        <div style={{
          background: C.rubyDeep,
          borderRadius: 4,
          overflow: 'hidden',
          boxShadow: '0 40px 120px rgba(0,0,0,0.6)',
          position: 'relative',
        }}>
          {/* Decorative rings */}
          {[500, 760].map(sz => (
            <div key={sz} style={{
              position: 'absolute', borderRadius: '50%',
              border: '1px solid rgba(255,255,255,0.07)',
              width: sz, height: sz,
              top: '50%', left: '30%',
              transform: 'translate(-50%,-50%)',
              pointerEvents: 'none',
            }} />
          ))}
          <div style={{
            position: 'absolute', top: -60, right: -60,
            width: 260, height: 260, borderRadius: '50%',
            border: '1px solid rgba(255,255,255,0.06)',
            pointerEvents: 'none',
          }} />

          {/* Body grid */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 400px',
            position: 'relative', zIndex: 2,
          }}>
            {/* ── LEFT ── */}
            <div style={{
              padding: '52px 48px 52px 56px',
              display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
              minHeight: 460,
            }}>
              {/* Brand */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 36 }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: 9,
                    background: 'rgba(255,255,255,0.15)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontFamily: FONTS.serif, fontSize: '1.2rem', color: 'white', fontWeight: 700,
                  }}>♦</div>
                  <span style={{ fontFamily: FONTS.serif, fontSize: '1.3rem', fontWeight: 700, color: 'white' }}>Her Ruby</span>
                </div>

                {/* Pilot badge */}
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 8,
                  background: 'rgba(240,214,136,0.15)',
                  border: '1px solid rgba(240,214,136,0.35)',
                  borderRadius: 100, padding: '6px 14px', marginBottom: 22,
                }}>
                  <div style={{
                    width: 7, height: 7, borderRadius: '50%',
                    background: C.goldLight, flexShrink: 0,
                    animation: 'blink 2s ease-in-out infinite',
                  }} />
                  <span style={{
                    fontFamily: FONTS.sans, fontSize: '0.7rem', fontWeight: 600,
                    color: C.goldLight, textTransform: 'uppercase', letterSpacing: '0.16em',
                  }}>Pilot Day · Free Event</span>
                </div>

                {/* Headline */}
                <h1 style={{
                  fontFamily: FONTS.serif,
                  fontSize: 'clamp(2.4rem,5vw,3.4rem)',
                  fontWeight: 700, lineHeight: 1.1,
                  color: 'white', letterSpacing: '-0.01em',
                  marginBottom: 14,
                }}>
                  Reclaim your energy,<br />
                  confidence &amp;{' '}
                  <em style={{ fontStyle: 'italic', color: 'rgba(255,255,255,0.7)' }}>vitality.</em>
                </h1>

                <p style={{
                  fontFamily: FONTS.sans,
                  fontSize: '0.95rem', color: 'rgba(255,255,255,0.68)',
                  lineHeight: 1.75, maxWidth: 380, marginBottom: 32,
                }}>
                  A morning designed for women 45–65 who are done putting themselves last.
                  Join us for an exclusive first look at Her Ruby.
                </p>

                {/* Event details */}
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 32 }}>
                  {[
                    { icon: '📅', text: 'Saturday, May 2, 2026' },
                    { icon: '🕙', text: '10:00 AM – 1:00 PM' },
                    { icon: '📍', text: 'Ontario, Canada — venue details on Eventbrite' },
                  ].map(({ icon, text }) => (
                    <div key={text} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div style={{
                        width: 34, height: 34, borderRadius: 9,
                        background: 'rgba(255,255,255,0.12)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: '0.95rem', flexShrink: 0,
                      }}>{icon}</div>
                      <span style={{ fontFamily: FONTS.sans, fontSize: '0.92rem', color: 'rgba(255,255,255,0.9)', fontWeight: 500 }}>
                        {text}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <a
                href={process.env.NEXT_PUBLIC_EVENTBRITE_URL || '#'}
                target="_blank" rel="noopener noreferrer"
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 10,
                  background: 'white', color: C.rubyDeep,
                  borderRadius: 12, padding: '14px 28px',
                  fontFamily: FONTS.sans, fontSize: '0.95rem', fontWeight: 600,
                  width: 'fit-content',
                  boxShadow: '0 8px 32px rgba(0,0,0,0.2)',
                  textDecoration: 'none',
                }}
              >
                Register on Eventbrite →
              </a>
            </div>

            {/* ── RIGHT PANEL ── */}
            <div style={{
              background: 'linear-gradient(160deg, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 100%)',
              borderLeft: '1px solid rgba(255,255,255,0.1)',
              padding: '52px 44px',
              display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
            }}>
              {/* What to expect */}
              <div>
                <div style={{
                  fontFamily: FONTS.sans, fontSize: '0.7rem', fontWeight: 600,
                  letterSpacing: '0.18em', textTransform: 'uppercase',
                  color: 'rgba(255,255,255,0.45)', marginBottom: 20,
                }}>
                  What to Expect
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 36 }}>
                  {EXPECT.map(item => (
                    <div key={item.n} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                      <div style={{
                        width: 28, height: 28, borderRadius: '50%',
                        background: 'rgba(240,214,136,0.2)',
                        border: '1px solid rgba(240,214,136,0.3)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontFamily: FONTS.serif, fontSize: '0.85rem', fontWeight: 700,
                        color: C.goldLight, flexShrink: 0, marginTop: 2,
                      }}>{item.n}</div>
                      <div style={{ fontFamily: FONTS.sans, fontSize: '0.88rem', color: 'rgba(255,255,255,0.8)', lineHeight: 1.6 }}>
                        <strong style={{ color: 'white' }}>{item.title}</strong> — {item.desc}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Who it's for */}
              <div>
                <div style={{
                  fontFamily: FONTS.sans, fontSize: '0.7rem', fontWeight: 600,
                  letterSpacing: '0.16em', textTransform: 'uppercase',
                  color: 'rgba(255,255,255,0.4)', marginBottom: 12,
                }}>
                  This is for you if you are…
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {BADGES.map(b => (
                    <span key={b} style={{
                      background: 'rgba(255,255,255,0.1)',
                      border: '1px solid rgba(255,255,255,0.15)',
                      borderRadius: 20, padding: '5px 12px',
                      fontFamily: FONTS.sans, fontSize: '0.75rem',
                      color: 'rgba(255,255,255,0.75)', fontWeight: 500,
                    }}>{b}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* ── BOTTOM STRIP ── */}
          <div style={{
            background: `linear-gradient(90deg, #5A1215, ${C.rubyDeep}, #9E2226)`,
            padding: '18px 56px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            borderTop: '1px solid rgba(255,255,255,0.1)',
            position: 'relative', zIndex: 2,
            flexWrap: 'wrap', gap: 12,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                background: 'rgba(240,214,136,0.2)',
                border: '1px solid rgba(240,214,136,0.4)',
                borderRadius: 8, padding: '4px 10px',
                fontFamily: FONTS.sans, fontSize: '0.72rem', fontWeight: 700,
                color: C.goldLight, letterSpacing: '0.08em', textTransform: 'uppercase',
              }}>FREE</div>
              <span style={{ fontFamily: FONTS.sans, fontSize: '0.82rem', color: 'rgba(255,255,255,0.65)' }}>
                No cost to attend — spaces are limited
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 7, height: 7, borderRadius: '50%',
                background: C.goldLight,
                animation: 'blink 1.5s ease-in-out infinite',
              }} />
              <span style={{ fontFamily: FONTS.sans, fontSize: '0.8rem', color: 'rgba(255,255,255,0.5)' }}>
                Limited spots available
              </span>
            </div>
            <div style={{ fontFamily: FONTS.sans, fontSize: '0.8rem', color: 'rgba(255,255,255,0.5)' }}>
              <a href="mailto:info@laelventures.com" style={{ color: 'rgba(255,255,255,0.7)', textDecoration: 'none' }}>
                info@laelventures.com
              </a>
              {' · '}herruby.ca
            </div>
          </div>
        </div>

        {/* Print/share tip */}
        <p style={{
          textAlign: 'center', marginTop: 24,
          fontFamily: FONTS.sans, fontSize: '0.8rem',
          color: 'rgba(255,255,255,0.3)',
        }}>
          Screenshot or print-to-PDF to share on Eventbrite and social media.
        </p>
      </div>

      <style>{`
        @media(max-width:700px){
          div[style*="grid-template-columns: 1fr 400px"]{
            grid-template-columns: 1fr !important;
          }
          div[style*="padding: 52px 48px 52px 56px"]{
            padding: 40px 28px !important;
          }
          div[style*="borderLeft: 1px solid"]{
            display: none !important;
          }
          div[style*="padding: 18px 56px"]{
            padding: 16px 28px !important;
            flex-direction: column !important;
            text-align: center;
          }
        }
        @media print {
          body { background: white !important; }
        }
      `}</style>
    </div>
  );
}
