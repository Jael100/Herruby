/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@herruby/ui'],
};
module.exports = nextConfig;
