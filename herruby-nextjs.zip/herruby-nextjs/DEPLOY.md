# Her Ruby — GitHub & Vercel Deployment Guide

> Deploy the landing page (`/`) and pilot subpage (`/pilot`) to Vercel in under 15 minutes.

---

## What you're deploying

| URL | Source |
|---|---|
| `herruby.ca` (or your Vercel URL) | `apps/web/` — Next.js 14 landing page |
| `herruby.ca/pilot` | `apps/web/app/pilot/` — Pilot event subpage |

Both pages are part of the same Next.js app. One Vercel deployment covers both.

---

## Prerequisites

Before you start, make sure you have:

- [ ] A **GitHub account** — github.com (free)
- [ ] A **Vercel account** — vercel.com (free Hobby plan is sufficient)
- [ ] The **`herruby-nextjs.zip`** file downloaded from Claude
- [ ] **Node.js 18+** installed if you want to test locally first

---

## Part 1 — Extract and prepare the files

### Step 1 · Unzip the project

On Mac:
```bash
unzip herruby-nextjs.zip
cd herruby-nextjs
```

On Windows: right-click `herruby-nextjs.zip` → Extract All → open the folder.

### Step 2 · (Optional) Test locally

```bash
# Install all dependencies
npm install

# Run the landing page on localhost:3001
npm run web:dev
```

Open `http://localhost:3001` — you should see the landing page.  
Open `http://localhost:3001/pilot` — you should see the pilot event subpage.

---

## Part 2 — Push to GitHub

### Step 3 · Create a new GitHub repository

1. Go to **github.com** and sign in
2. Click the **+** icon (top right) → **New repository**
3. Set:
   - Repository name: `herruby` (or `herruby-web`)
   - Visibility: **Private** ← important, keeps your code private
   - Do **not** tick "Add a README" (you already have one)
4. Click **Create repository**

GitHub will show you a page with setup commands. Keep this tab open.

### Step 4 · Initialise Git in your project folder

Open Terminal (Mac) or Command Prompt (Windows) and navigate to the unzipped folder:

```bash
cd herruby-nextjs

# Initialise git
git init

# Stage all files
git add .

# First commit
git commit -m "Initial commit — Her Ruby landing page + pilot subpage"
```

### Step 5 · Connect to GitHub and push

Copy the commands from the GitHub page (they include your username). They look like this:

```bash
git remote add origin https://github.com/YOUR-USERNAME/herruby.git
git branch -M main
git push -u origin main
```

After running these, refresh your GitHub page — all 78 files should appear.

---

## Part 3 — Deploy to Vercel

### Step 6 · Import your repository into Vercel

1. Go to **vercel.com** and sign in (or sign up with your GitHub account)
2. From your Vercel dashboard, click **Add New…** → **Project**
3. Click **Continue with GitHub** if prompted
4. Find `herruby` in the repository list → click **Import**

### Step 7 · Configure the project settings

Vercel will show a configuration screen. Set these values:

| Setting | Value |
|---|---|
| **Framework Preset** | Next.js (auto-detected) |
| **Root Directory** | `apps/web` |
| **Build Command** | `cd ../.. && npm install && npm run web:build` |
| **Output Directory** | `.next` |
| **Install Command** | *(leave blank)* |

> **Important:** Setting Root Directory to `apps/web` tells Vercel where your Next.js app lives inside the monorepo.

### Step 8 · Add environment variables

Still on the configuration screen, scroll to **Environment Variables** and add each one:

| Key | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://your-ref.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `eyJhb...` (from Supabase dashboard) |
| `NEXT_PUBLIC_EVENTBRITE_URL` | Your Eventbrite event URL |
| `NEXT_PUBLIC_APP_URL` | `https://herruby.ca` (or your Vercel URL for now) |

> You can skip Supabase keys for now and add them later in Project Settings → Environment Variables. The site will still build and display correctly.

### Step 9 · Deploy

Click **Deploy**.

Vercel will:
1. Clone your repo
2. Install dependencies
3. Build the Next.js app (`npm run web:build`)
4. Deploy to a `.vercel.app` URL

This takes **2–4 minutes**. You'll see a live build log.

When it finishes, Vercel gives you a URL like:
```
https://herruby-abc123.vercel.app
```

Test both pages:
- `https://herruby-abc123.vercel.app` → Landing page ✓
- `https://herruby-abc123.vercel.app/pilot` → Pilot subpage ✓

---

## Part 4 — Connect your custom domain (optional)

### Step 10 · Add your domain in Vercel

1. In your Vercel project, go to **Settings** → **Domains**
2. Type `herruby.ca` → click **Add**
3. Vercel shows you DNS records to add

### Step 11 · Update your DNS

Log in to your domain registrar (e.g. GoDaddy, Namecheap, Google Domains) and add:

| Type | Name | Value |
|---|---|---|
| `A` | `@` | `76.76.21.21` |
| `CNAME` | `www` | `cname.vercel-dns.com` |

DNS changes take 5–30 minutes to propagate. Once done, your site is live at `herruby.ca` and `herruby.ca/pilot`.

---

## Part 5 — Future updates (the deploy loop)

Every time you update the landing page or pilot subpage, the process is:

```bash
# 1. Make your changes in any editor (VS Code, etc.)

# 2. Stage and commit
git add .
git commit -m "Update: [describe what you changed]"

# 3. Push to GitHub
git push

# Vercel automatically detects the push and redeploys in ~2 minutes
```

That's it. No manual Vercel steps needed after the first setup — every `git push` triggers an automatic redeploy.

---

## Quick reference — files that control each page

| File | What it controls |
|---|---|
| `apps/web/app/page.jsx` | Home page (`/`) — assembles all sections |
| `apps/web/app/sections/Hero.jsx` | Hero section text and buttons |
| `apps/web/app/sections/GiftOfHealth.jsx` | Gift of Health section + modals |
| `apps/web/app/sections/Solution.jsx` | Four pillars section |
| `apps/web/app/sections/Footer.jsx` | Footer links, contact form |
| `apps/web/app/pilot/page.jsx` | Pilot event subpage (`/pilot`) |
| `apps/web/app/pilot/PilotSignup.jsx` | Pilot registration form |
| `apps/web/app/components/Nav.jsx` | Navigation bar (all pages) |
| `apps/web/.env.local.example` | All environment variable names |
| `packages/ui/src/tokens.js` | Brand colours, fonts, credit packs |

---

## Troubleshooting

**Build fails with "Cannot find module '@herruby/ui'"**
→ Make sure Root Directory is set to `apps/web` in Vercel, and Build Command is `cd ../.. && npm install && npm run web:build`

**Environment variables not working**
→ In Vercel: Settings → Environment Variables → verify they're set for Production. Then Deployments → Redeploy.

**Pilot page shows 404**
→ Next.js App Router creates routes from folder names. Confirm `apps/web/app/pilot/page.jsx` exists in your repo on GitHub.

**Google Fonts not loading**
→ The fonts load from `globals.css` via a Google Fonts import. This requires internet access during build — Vercel has this by default.

---

## Contact & Support

**Her Ruby / Lael Ventures**  
info@laelventures.com · Ontario, Canada
